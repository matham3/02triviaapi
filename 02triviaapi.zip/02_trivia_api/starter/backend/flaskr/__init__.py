import os
import random
from flask import Flask, request, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, distinct
from flask_cors import CORS
from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10


def create_app(test_config=None):
    # 'create and configure the app'

    app = Flask(__name__)

    setup_db(app)

    '''
    @DONE: Set up CORS. Allow '*' for origins.
          Delete the sample route after completing the TODOs
    '''
    CORS(app, resources={r"/*": {"origins": "*"}})

    '''
    @DONE: Use the after_request decorator to
          set Access-Control-Allow
    '''
    @app.after_request
    def add_header_after_request(resp):
        """ set Access-Control-Allow """

        resp.headers.add(
            "Access-Control-Allow-Headers",
            "Content-Type, Authorization"
          )

        resp.headers.add(
            "Access-Control-Allow-Methods",
            "GET, PUT, POST, DELETE"
          )

        return resp

    '''
    @DONE:
    Create an endpoint to handle GET requests
    for all available categories.
    '''
    @app.route("/categories")
    def get_all_categories():
        """Get All Categories"""

        result = {
            category.id: category.type
            for category in Category.query.all()
          }

        return jsonify({"categories":result})

    '''
    @DONE:
    Create an endpoint to handle GET requests for questions,
    including pagination (every 10 questions).
    This endpoint should return a list of questions,
    number of total questions, current category, categories.

    TEST: At this point, when you start the application
    you should see questions and categories generated,
    ten questions per page and pagination at the bottom
    of the screen for three pages.
    Clicking on the page numbers should update the questions.
    '''
    @app.route('/question')
    def get_all_questions():
        """ Get all  Questions"""
        page = int(request.args.get("page", 1))

        questions = Question.query.paginate(
            page, QUESTIONS_PER_PAGE
          )

        questions_items = [q.format() for q in questions.items]

        return jsonify({
              "questions": questions_items,
              "total_questions": questions.total,
              "current_category": "",
              'categories': {
                  c.id: c.type for c in Category.query.all()
                }
          })

    '''
    @DONE:
    Create an endpoint to DELETE question using a question ID.

    TEST: When you click the trash icon next to a question, the question will be removed.
    This removal will persist in the database and when you refresh the page.
    '''
    @app.route("/question/<int:id>", methods={"DELETE"})
    def deleted_question_by_id(id):
        question = Question.query.get(id)

        if not question:
            abort(404)

        question.delete()

        return jsonify({
            'success': True,
            "message": f"Deleted Successfully Question Id {id}"
          })

    '''
    @DONE:
    Create an endpoint to POST a new question,
    which will require the question and answer text,
    category, and difficulty score.

    TEST: When you submit a question on the "Add" tab,
    the form will clear and the question will appear at the end of the last page
    of the questions list in the "List" tab.
    '''
    @app.route("/question", methods={"POST"})
    def added_new_question():
        dataJson = request.json

        if not dataJson:
            abort(422)


        if request.is_json and (
                (dataJson.get("question") == "") or
                (dataJson.get("answer") == "") or
                (dataJson.get("category") == "") or
                (dataJson.get("difficulty") == "")
              ):

          abort(422)

            
        new_question = Question(
            question=dataJson.get("question"),
            answer=dataJson.get("answer"),
            category=dataJson.get("category"),
            difficulty=dataJson.get("difficulty"))

        new_question.insert()

        return jsonify({
              'success': True,
              "message": "Added Successfully Question"
            })

    '''
    @DONE: 
    Create a POST endpoint to get questions based on a search term. 
    It should return any questions for whom the search term 
    is a substring of the question. 

    TEST: Search by any phrase. The questions list will update to include 
    only question that include that string within their question. 
    Try using the word "title" to start. 
    '''
    @app.route("/question/search", methods={"POST"})
    def search_in_questions(): 

      search = request.json.get("searchTerm", "")

      questions = Question.query.filter(
            Question.question.ilike(f"%{search}%")
        ).paginate(1, QUESTIONS_PER_PAGE)

      questions = [question.format() for question in questions.items]

      if len(questions):
          abort(404)
      
      return jsonify({
            'success': True,
            "questions": questions,
            "total_questions": len(questions),
            "current_category": "",
            'categories': { 
                  c.id: c.type for c in Category.query.all() 
              }
        })

   
    '''
    @DONE: 
    Create a GET endpoint to get questions based on category. 

    TEST: In the "List" tab / main screen, clicking on one of the 
    categories in the left column will cause only questions of that 
    category to be shown. 
    '''
    @app.route("/category/<int:id>/questions")
    def get_questions_by_category_id(id):
      category = Category.query.get(id)

      if not category:
        abort(404)

      questions = Question.query.filter(
              Question.category == id
          ).paginate(1, QUESTIONS_PER_PAGE)
      questions = [dict(question.format()) for question in questions.items]


      return jsonify({
            'success': True,
            "questions": questions,
            "total_questions": len(questions),
            "current_category": category.type,
            'categories': { 
                c.id: c.type for c in Category.query.all() 
              }
        })


    '''
    @DONE: 
    Create a POST endpoint to get questions to play the quiz. 
    This endpoint should take category and previous question parameters 
    and return a random questions within the given category, 
    if provided, and that is not one of the previous questions. 

    TEST: In the "Play" tab, after a user selects "All" or a category,
    one question at a time is displayed, the user is allowed to answer
    and shown whether they were correct or not. 
    '''
    @app.route("/quiz", methods={"POST"})
    def play_quiz():
      dataJson = request.json
      previous_questions = dataJson.get("previous_questions")
      quiz_category = dataJson.get("quiz_category")



      question = Question.query.filter(
              Question.id.notin_(previous_questions)
          )

      if quiz_category:
          question = question.filter_by(
              category=quiz_category.get("id")
            )


      question = question.order_by(func.random()).first()


      if not question:
        abort(404)

      return jsonify({
          'success': True,
          "question": question.format()
        })



    '''
    @DONE: 
    Create error handlers for all expected errors 
    including 404 and 422. 
    '''
    @app.errorhandler(404)
    def error_handler_notfound(err):
      """error handler `Not Found ` """

      return jsonify({
        'success': False,
        'message': 'Not found '
      }), 404

    @app.errorhandler(422)
    def error_handler_unprocessable(err):
      """error handler `Unprocessable Entity ` """

      return jsonify({
        'success': False,
        'message': 'Unprocessable Entity'
      }), 422

    @app.errorhandler(400)
    def error_handler_bad_request(err):
      """error handler `Bad Request` """

      return jsonify({
        'success': False,
        'message': 'Bad Request'
      }), 400
    

    @app.errorhandler(500)
    def error_handler_internal_server(err):
      """error handler `Internal Server` """

      return jsonify({
        'success': False,
        'message': 'Internal Server'
      }), 500


    # 
    return app
