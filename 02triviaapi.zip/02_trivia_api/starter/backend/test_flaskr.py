import os
import unittest
import json
from flask_sqlalchemy import SQLAlchemy

from flaskr import create_app
from models import setup_db, Question, Category


class TriviaTestCase(unittest.TestCase):
    """This class represents the trivia test case"""

    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_app()
        self.client = self.app.test_client
        self.database_name = "trivia_test"
        self.database_path = "postgres://{}/{}".format('localhost:5432', self.database_name)
        setup_db(self.app, self.database_path)

        # binds the app to the current context
        with self.app.app_context():
            self.db = SQLAlchemy()
            self.db.init_app(self.app)
            # create all tables
            self.db.create_all()
    
    def tearDown(self):
        """Executed after reach test"""

        with self.app.app_context():
            self.db.session.remove()
            self.db.drop_all()


    """
    TODO
    Write at least one test for each test for successful operation and for expected errors.
    """
    def test_categories(self):
        """Test get all categories"""


        resp = self.client().get("/categories")
        dataJson = json.loads(resp.data)

        self.assertEqual(resp.status_code, 200)
        self.assertTrue(isinstance(dataJson.get("categories"), dict))
        self.assertEqual( len(dataJson.get("categories")), Category.query.count() )

    def test_questions(self):
        """Test get all questions"""

        resp = self.client().get("/question")
        dataJson = json.loads(resp.data)

        self.assertEqual(resp.status_code, 200)
        self.assertEqual(
            dataJson.get("total_questions"), 
            Question.query.count() 
        )

    def test_questions_not_found(self):
        """Test get all questions"""

        resp = self.client().get("/question?page=1000")
        dataJson = json.loads(resp.data)

        self.assertEqual(resp.status_code, 404)
        self.assertFalse(dataJson.get("status"))


    def test_delete_questions_by_id(self):
        """Test delete questions by id"""

        # create  test question 
        question = Question(
                question="test question ?",
                answer="test answer",
                category="1",
                difficulty=8
            )
        question.insert()


        resp = self.client().delete("/question/%s"%question.id)
        dataJson = json.loads(resp.data)
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(dataJson.get("success"))

    def test_delete_question_with_invalid_id(self):
        """ Test delete if not found question """

        resp = self.client().delete("/question/10010")
        self.assertEqual(resp.status_code, 404)

    def test_create_new_question(self):
        """test create question"""

        resp = self.client().post(
                "/question", 
                json={
                    'question': "Hello World Test?",
                    'answer': "hi, world !",
                    'difficulty': 5,
                    'category': "2"
                }
        )

        dataJson = json.loads(resp.data)

        self.assertEqual(resp.status_code, 200)
        self.assertTrue(dataJson.get("success"))

    def test_create_question_with_invalid_data(self):
        """Test Create Question With Invalid Data"""

        resp = self.client().post(
                "/question", 
                json={}
            )

        self.assertEqual(resp.status_code, 422)

    def test_search(self):
        """Test search """

        resp = self.client().post(
                "/question/search",
                json={"searchTerm": "suqu"}
            )

        self.assertEqual(resp.status_code, 200)

    def test_search_with_invalid_data(self):
        """Test search """

        resp = self.client().post(
                "/question/search",
                json={}
            )

        self.assertEqual(resp.status_code, 404)


    def test_get_question_by_category(self):
        """Test get questions by id category"""

        resp = self.client().get(
                "/category/2/questions"
            )

        self.assertEqual(resp.status_code, 200)

    def test_get_question_by_invalid_category(self):
        """Test get question by notfound category"""
        resp = self.client().get(
                "/category/50000/questions"
            )

        self.assertEqual(resp.status_code, 404)

    def test_quiz(self):
        """Test play quiz"""
        resp = self.client().post(
                "/quiz",
                json={
                    'quiz_category': {'type': 'sport', 'id': '2'},
                    "previous_questions": []
                }
            )   

        self.assertEqual(resp.status_code, 200)

    def test_quiz_not_found_questions(self):
        """Test quiz with invalid quiz category"""

        resp = self.client().post(
            "/quiz",
            json={
                'quiz_category':  {'type': 'none', 'id': '10220'},
                "previous_questions": []
            }
        )  

        self.assertEqual(resp.status_code, 404)


# Make the tests conveniently executable
if __name__ == "__main__":
    unittest.main()